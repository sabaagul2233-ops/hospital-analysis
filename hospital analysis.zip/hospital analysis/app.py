import streamlit as st
import pandas as pd

st.set_page_config(page_title="Hospital Data Analytics Dashboard", layout="wide")

st.title("Hospital Data Analytics Dashboard")
st.write("This dashboard analyses patients, departments, doctors, admissions, treatment cost and disease trends.")

df = pd.read_csv("hospital_data.csv")

df["Admission_Date"] = pd.to_datetime(df["Admission_Date"])
df["Discharge_Date"] = pd.to_datetime(df["Discharge_Date"])
df["Stay_Days"] = (df["Discharge_Date"] - df["Admission_Date"]).dt.days
df["Admission_Month"] = df["Admission_Date"].dt.strftime("%Y-%m")

st.sidebar.header("Filters")

selected_department = st.sidebar.multiselect("Select Department", df["Department"].unique(), default=df["Department"].unique())
selected_doctor = st.sidebar.multiselect("Select Doctor", df["Doctor"].unique(), default=df["Doctor"].unique())
selected_city = st.sidebar.multiselect("Select City", df["City"].unique(), default=df["City"].unique())
selected_gender = st.sidebar.multiselect("Select Gender", df["Gender"].unique(), default=df["Gender"].unique())

filtered_df = df[
    (df["Department"].isin(selected_department)) &
    (df["Doctor"].isin(selected_doctor)) &
    (df["City"].isin(selected_city)) &
    (df["Gender"].isin(selected_gender))
]

st.subheader("Key Hospital Metrics")

total_patients = filtered_df["Patient_ID"].nunique()
total_revenue = filtered_df["Treatment_Cost"].sum()
average_treatment_cost = filtered_df["Treatment_Cost"].mean()
average_stay_days = filtered_df["Stay_Days"].mean()
emergency_cases = filtered_df[filtered_df["Case_Type"] == "Emergency"].shape[0]

col1, col2, col3, col4, col5 = st.columns(5)
col1.metric("Total Patients", total_patients)
col2.metric("Total Revenue", f"Rs. {total_revenue:,.0f}")
col3.metric("Avg Treatment Cost", f"Rs. {average_treatment_cost:,.0f}")
col4.metric("Avg Stay Days", f"{average_stay_days:.1f}")
col5.metric("Emergency Cases", emergency_cases)

st.subheader("Hospital Dataset")
st.dataframe(filtered_df)

st.subheader("Department Wise Patients")
department_patients = filtered_df.groupby("Department")["Patient_ID"].count().sort_values(ascending=False)
st.bar_chart(department_patients)

st.subheader("Doctor Wise Patients")
doctor_patients = filtered_df.groupby("Doctor")["Patient_ID"].count().sort_values(ascending=False)
st.bar_chart(doctor_patients)

st.subheader("City Wise Patients")
city_patients = filtered_df.groupby("City")["Patient_ID"].count().sort_values(ascending=False)
st.bar_chart(city_patients)

st.subheader("Monthly Admission Trend")
monthly_admissions = filtered_df.groupby("Admission_Month")["Patient_ID"].count()
st.line_chart(monthly_admissions)

st.subheader("Disease Wise Patients")
disease_count = filtered_df.groupby("Disease")["Patient_ID"].count().sort_values(ascending=False)
st.dataframe(disease_count)

st.subheader("Case Type Analysis")
case_type_count = filtered_df["Case_Type"].value_counts()
st.bar_chart(case_type_count)

st.subheader("High Cost Treatment Records")
high_cost_records = filtered_df[filtered_df["Treatment_Cost"] > 60000]
st.dataframe(high_cost_records)

st.subheader("Department Wise Revenue")
department_revenue = filtered_df.groupby("Department")["Treatment_Cost"].sum().sort_values(ascending=False)
st.bar_chart(department_revenue)

st.subheader("Business / Management Insights")

if not filtered_df.empty:
    busiest_department = department_patients.idxmax()
    highest_revenue_department = department_revenue.idxmax()
    busiest_doctor = doctor_patients.idxmax()
    top_city = city_patients.idxmax()

    st.write(f"Busiest department is: **{busiest_department}**")
    st.write(f"Highest revenue department is: **{highest_revenue_department}**")
    st.write(f"Doctor handling most patients is: **{busiest_doctor}**")
    st.write(f"City with highest patient count is: **{top_city}**")
else:
    st.warning("No data available for selected filters.")
